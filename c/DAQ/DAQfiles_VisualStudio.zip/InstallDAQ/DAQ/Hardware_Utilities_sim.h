// The WIN32_LEAN_AND_MEAN macro prevents the Winsock.h from being included by the Windows.h header. 
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

// Simulator
#pragma comment( lib, "libHWutils.a" )
int init_daq(int config_type);
int user_has_quit(void);
int read_binary(int channel_number);
void write_binary(int channel_number, int value);
void write_display(int data, int position);
float read_analog(int analog_channel_number);

// Global flag for this header file
static int g_Flag_SetUp=-1;

int setupDAQ(int setupNum) {
	if(setupNum == 0)
	{
		g_Flag_SetUp = 0;
		printf("\nError: Hardware is not supported by this simulator only library --> Did you choose 0 for setupNum! ... exiting\n");
		system("pause");
		exit(0);
	}
	else {
		g_Flag_SetUp = setupNum;
		return init_daq(setupNum);
	}
}

int digitalRead(int channel_number)
{

	if(g_Flag_SetUp == 0) {
		printf("Error: Hardware is not supported by this simulator only library --> Did you choose 0 for setupNum!\n");
		exit(0);
	}
	else if(g_Flag_SetUp == -1)	{
		printf("\nError in calling digitalRead: DAQ is not setup --> exiting\n\n!");
		system("pause");
		exit(0);
	}
	else
		return read_binary(channel_number);
}

double analogRead(int channel_number)
{
	if(g_Flag_SetUp == 0){
		printf("Error: Hardware is not supported by this simulator only library --> Did you choose 0 for setupNum!\n");
		exit(0);
	}
	else if(g_Flag_SetUp == -1)
	{
		printf("\nError in calling analogRead: DAQ is not setup --> exiting\n\n!");
		system("pause");
		exit(0);
	}
	else
		return (double) read_analog(channel_number);
}

void digitalWrite(int channel_number, int val)
{
	if(g_Flag_SetUp == 0) {
		printf("Error: Hardware is not supported by this simulator only library --> Did you choose 0 for setupNum!\n");
		exit(0);
	}
	else if(g_Flag_SetUp == -1)	{
		printf("\nError in calling digitalWrite: DAQ is not setup --> exiting\n\n!");
		system("pause");
		exit(0);
	}
	else
		write_binary(channel_number, val);
}

void displayWrite(int data, int position)
{
	if(position > 7 || position < 0) {
		printf("\nERROR in calling displayWrite(): position out of bound!\n\n");
		return;
	}
	if(data < 0 || data > 255) {
		printf("\nERROR in calling displayWrite(): data out of bound!\n\n");
		return;
	}
	// Change the data standard to a simpler one. 
	// using: abcdefgp (or pgfedcba) as opposed to gpcbafed
	// to have gpcbafed <-- abcdefgp
	data = (data & 128) >> 4 | // a
		(data & 64) >> 2 | // b
		(data & 32) | // c
		(data & 16) >> 4 | // d
		(data & 8) >> 2 | // e
		(data & 4)  | // f
		(data & 2) << 6 |  // g
		(data & 1) << 6;  // p
	
	// Change the order of position to a simpler one. 
	// using: 7 <--> 0 as opposed to 0 <--> 7
	position = 7 - position;

	if(g_Flag_SetUp == 0) {
		printf("Error: Hardware is not supported by this simulator only library --> Did you choose 0 for setupNum!\n");
		exit(0);
	}
	else if(g_Flag_SetUp == -1)	{
		printf("\nError in calling displayWrite(): DAQ is not setup --> exiting!\n\n");
		system("pause");
		exit(0);
	}
	else
		write_display(data, position);
}

int continueSuperLoop(void)
{
	if(g_Flag_SetUp == 0) {
		printf("Error: Hardware is not supported by this simulator only library --> Did you choose 0 for setupNum!\n");
		exit(0);
	}
	else if(g_Flag_SetUp == -1)	{
		printf("\nError in calling continueSuperLoop: DAQ is not setup --> exiting!\n\n");
		system("pause");
		exit(0);
	}
	else
		return !user_has_quit();
}