/*

This header file is the main header to be included in order to use 
the DAQ hardware or the simulator.

*/

// http://msdn.microsoft.com/en-us/library/3tz4da4a(v=vs.80).aspx
#pragma comment(linker, "/NODEFAULTLIB:LIBCMT")
#pragma comment(linker, "/NODEFAULTLIB:MSVCRT")

/*
This function is used to perform any necessary initialization for
the hardware module and/or the simulator.  It must be called
before any of the other functions can be used.  It also creates the
appropriate simulator window, depending on the value of config_type.
*/
int setupDAQ(int setupNum);

/*
This function is used to read the given digital channel and
returns a value of either 0 or 1.
*/
int digitalRead(int channelNumber);

/*
This function is used to read the given analog channel
*/
double analogRead(int channelNumber);

/*
This function is used to write the given value to the
digital channel.  The value can either be 0 or 1.
*/
void digitalWrite(int channelNumber, int val);

/*
This function is used to write the given 'data' to
the LED display at 'position'.  Note that position
starts at zero from the left.
*/
void displayWrite(int data, int position);


/*
This function is used to determine whether the user has quit the
DAQ window.  It returns TRUE only when the DAQ window has been quit 
by the user.  Once this function returns TRUE, do not call any
of the other functions below.
*/
int continueSuperLoop(void);

#include "Hardware_Utilities_sim.h"